-- Initialize pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;
