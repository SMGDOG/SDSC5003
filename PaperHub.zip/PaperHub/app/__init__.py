"""
PaperHub - 个人学术论文管理与推荐系统
"""
__version__ = "1.0.0"
